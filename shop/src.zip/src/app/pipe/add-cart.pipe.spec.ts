import { AddCartPipe } from './add-cart.pipe';

describe('AddCartPipe', () => {
  it('create an instance', () => {
    const pipe = new AddCartPipe();
    expect(pipe).toBeTruthy();
  });
});
