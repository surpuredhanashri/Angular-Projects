export class Dash{
    id:number=0;
    name:string="";
    email:string="";
    mobile:number=0;


    constructor(id:number,name:string, email:string,mobile:number){
        this.id = id;
        this.name =name;
        this.email= email;
        this.mobile = mobile;
    }
}